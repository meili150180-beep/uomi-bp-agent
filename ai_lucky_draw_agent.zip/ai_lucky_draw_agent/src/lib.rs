use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::{seq::SliceRandom, SeedableRng, rngs::StdRng};

#[derive(Deserialize)]
struct Input {
    participants: Vec<String>,
    num_winners: usize,
    seed: Option<u64>,
}

#[derive(Serialize)]
struct Output {
    winners: Vec<String>,
    explanation: String,
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    // Parse input safely
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        participants: vec!["Alice".to_string(), "Bob".to_string(), "Charlie".to_string()],
        num_winners: 1,
        seed: None,
    });

    let mut participants = input.participants.clone();
    let n = participants.len().min(input.num_winners.max(1));

    // Randomize with or without seed
    let winners = if let Some(seed) = input.seed {
        let mut rng = StdRng::seed_from_u64(seed);
        participants.shuffle(&mut rng);
        participants.into_iter().take(n).collect::<Vec<_>>()
    } else {
        let mut rng = rand::thread_rng();
        participants.shuffle(&mut rng);
        participants.into_iter().take(n).collect::<Vec<_>>()
    };

    let explanation = format!(
        "Winners selected randomly from {} participants using {}random seed.",
        input.participants.len(),
        if input.seed.is_some() { "a fixed " } else { "a " }
    );

    let output = Output { winners, explanation };
    serde_json::to_string(&output).unwrap()
}
