use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::Rng;

#[derive(Deserialize)]
struct Input {
    user: String,
    tier: String,
    activity_score: Option<f64>,
    bet_amount: Option<f64>,
}

#[derive(Serialize)]
struct Output {
    winner: bool,
    reward: f64,
    chance: f64,
    explanation: String,
}

fn clamp01(x: f64) -> f64 {
    if x.is_finite() { x.max(0.0).min(1.0) } else { 0.5 }
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let default = Input {
        user: "guest".to_string(),
        tier: "normal".to_string(),
        activity_score: Some(50.0),
        bet_amount: Some(100.0),
    };
    let input: Input = serde_json::from_str(input_json).unwrap_or(default);
    let mut rng = rand::thread_rng();

    let score = clamp01(input.activity_score.unwrap_or(50.0) / 100.0);
    let bet_factor = clamp01((input.bet_amount.unwrap_or(100.0).ln() / 10.0).min(1.0));
    let tier_bonus = if input.tier.to_lowercase() == "premium" { 0.25 } else { 0.0 };

    let mut chance = 0.05 + (score * 0.3) + (bet_factor * 0.1) + tier_bonus;
    chance = chance.min(0.95);

    let roll: f64 = rng.gen_range(0.0..1.0);
    let winner = roll < chance;

    let mut reward = 0.0;
    if winner {
        let base_reward = if input.tier.to_lowercase() == "premium" { 500.0 } else { 200.0 };
        let multiplier = 1.0 + (score * 0.5) + (bet_factor * 0.5);
        reward = base_reward * multiplier;
    }

    let explanation = format!(
        "User {} (tier: {}), activity {:.1}%, bet {:.2}, roll {:.2}, chance {:.2}.",
        input.user,
        input.tier,
        score * 100.0,
        input.bet_amount.unwrap_or(0.0),
        roll,
        chance
    );

    let out = Output { winner, reward, chance, explanation };
    serde_json::to_string(&out).unwrap()
}
