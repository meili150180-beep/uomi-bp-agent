use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
struct Input {
    message: String,
}

#[derive(Serialize)]
struct Output {
    reply: String,
}

fn respond(msg: &str) -> String {
    let m = msg.trim().to_lowercase();
    if m.contains("hello") || m.contains("hi") || m.contains("hey") {
        "Hi there! How can I help you today?".to_string()
    } else if m.contains("who are you") || m.contains("what are you") {
        "I am your AI Dialogue Agent built with Rust and WebAssembly.".to_string()
    } else if m.contains("bye") || m.contains("goodbye") {
        "Goodbye! Have a great day!".to_string()
    } else if m.contains("help") {
        "Sure—tell me what you need help with, and I'll do my best.".to_string()
    } else if m.contains("time") {
        "I don't have a realtime clock here, but I'm ready whenever you are.".to_string()
    } else {
        "I'm not sure yet, but I'll keep learning. Try asking in another way!".to_string()
    }
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        message: "hello".to_string(),
    });
    let reply = respond(&input.message);
    let out = Output { reply };
    serde_json::to_string(&out).unwrap()
}
