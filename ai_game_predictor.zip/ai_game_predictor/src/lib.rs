use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::Rng;

#[derive(Deserialize)]
struct Input {
    player_a: String,
    player_b: String,
    score_a: Option<f64>,
    score_b: Option<f64>,
}

#[derive(Serialize)]
struct Output {
    prediction: String,
    confidence: f64,
    explanation: String,
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        player_a: "A".to_string(),
        player_b: "B".to_string(),
        score_a: Some(50.0),
        score_b: Some(50.0),
    });

    let mut rng = rand::thread_rng();
    let diff = input.score_a.unwrap_or(0.0) - input.score_b.unwrap_or(0.0);
    let base_conf = 0.5 + diff / 200.0;
    let random_factor: f64 = rng.gen_range(-0.05..0.05);
    let confidence = (base_conf + random_factor).clamp(0.1, 0.9);

    let winner = if confidence >= 0.5 {
        input.player_a.clone()
    } else {
        input.player_b.clone()
    };

    let explanation = format!(
        "{} predicted to win with confidence {:.2} (scores {:.1} vs {:.1})",
        winner, confidence, input.score_a.unwrap_or(0.0), input.score_b.unwrap_or(0.0)
    );

    let output = Output {
        prediction: winner,
        confidence,
        explanation,
    };

    serde_json::to_string(&output).unwrap()
}
