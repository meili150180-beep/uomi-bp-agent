use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::Rng;

#[derive(Deserialize)]
struct Input {
    direction: String,
    amount: f64,
    prediction: String,
    confidence: f64,
}

#[derive(Serialize)]
struct Output {
    result: String,
    payout: f64,
    explanation: String,
}

fn norm_dir(s: &str) -> String {
    let m = s.trim().to_lowercase();
    match m.as_str() {
        "up" | "down" | "neutral" => m,
        _ => "neutral".to_string(),
    }
}

fn clamp01(x: f64) -> f64 {
    if x.is_finite() { x.max(0.0).min(1.0) } else { 0.5 }
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let default = Input {
        direction: "up".to_string(),
        amount: 10.0,
        prediction: "up".to_string(),
        confidence: 0.6,
    };
    let mut input: Input = serde_json::from_str(input_json).unwrap_or(default);
    input.direction = norm_dir(&input.direction);
    input.prediction = norm_dir(&input.prediction);
    input.confidence = clamp01(input.confidence);
    let amount = if input.amount.is_finite() { input.amount.abs() } else { 0.0 };

    let mut win_chance = if input.direction == input.prediction {
        0.5 + (0.4 * input.confidence)
    } else {
        (0.3 - (0.2 * input.confidence)).max(0.05)
    };

    let mut rng = rand::thread_rng();
    let jitter: f64 = rng.gen_range(-0.03..0.03);
    win_chance = (win_chance + jitter).max(0.02).min(0.98);

    let roll: f64 = rng.gen_range(0.0..1.0);
    let mut result = "lose".to_string();
    let mut payout = -amount;

    if roll < win_chance {
        result = "win".to_string();
        let base_mult = 1.6 + (input.confidence * 0.6);
        let dir_bonus = if input.direction == "neutral" { 0.2 } else { 0.0 };
        payout = amount * (base_mult + dir_bonus);
    }

    let explanation = format!(
        "Direction bet: {}, AI predicted: {} (conf {:.2}), win_chance {:.2}, roll {:.2}.",
        input.direction, input.prediction, input.confidence, win_chance, roll
    );

    let out = Output { result, payout, explanation };
    serde_json::to_string(&out).unwrap()
}
