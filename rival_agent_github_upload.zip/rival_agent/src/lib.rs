use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
struct Input {
    left: String,
    right: String,
    left_score: Option<f64>,
    right_score: Option<f64>,
    rule: Option<String>,
}

#[derive(Serialize)]
struct Output {
    winner: String,
    loser: String,
    explanation: String,
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        left: "A".to_string(),
        right: "B".to_string(),
        left_score: Some(0.0),
        right_score: Some(0.0),
        rule: Some("higher_wins".to_string()),
    });

    let left = input.left;
    let right = input.right;
    let l = input.left_score.unwrap_or(0.0);
    let r = input.right_score.unwrap_or(0.0);
    let rule = input.rule.unwrap_or("higher_wins".to_string());

    let (winner, loser, explanation) = if (rule == "higher_wins" && l >= r)
        || (rule == "lower_wins" && l <= r)
    {
        (left.clone(), right.clone(), format!("{} wins over {}!", left, right))
    } else {
        (right.clone(), left.clone(), format!("{} wins over {}!", right, left))
    };

    serde_json::to_string(&Output { winner, loser, explanation }).unwrap()
}
