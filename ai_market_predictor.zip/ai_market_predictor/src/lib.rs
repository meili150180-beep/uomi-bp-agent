use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::Rng;

#[derive(Deserialize)]
struct Input {
    asset: String,
    price: f64,
    change_24h: f64,         // in percent, e.g. 2.5 means +2.5%
    volume: Option<f64>,     // optional 24h volume
}

#[derive(Serialize)]
struct Output {
    prediction: String,      // "up" | "down" | "neutral"
    confidence: f64,         // 0.0 .. 1.0
    explanation: String,
}

fn sigmoid(x: f64) -> f64 {
    1.0 / (1.0 + (-x).exp())
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    // Parse input safely with defaults
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        asset: "ASSET".to_string(),
        price: 100.0,
        change_24h: 0.0,
        volume: Some(0.0),
    });

    // Normalize signals
    let momentum = input.change_24h / 10.0; // +/-10% -> +/-1.0
    let vol = input.volume.unwrap_or(0.0);
    let vol_score = (vol.ln().max(0.0) / 10.0).min(1.0); // crude scaling

    // Base probability from momentum
    let base = sigmoid(momentum);

    // Add a tiny random jitter (±0.03) so outputs aren't identical
    let mut rng = rand::thread_rng();
    let jitter: f64 = rng.gen_range(-0.03..0.03);

    // Blend: 70% momentum, 20% volume, 10% random
    let mut prob_up = (0.7 * base) + (0.2 * vol_score) + (0.1 * (0.5 + jitter));
    prob_up = prob_up.clamp(0.05, 0.95);

    let prediction = if prob_up > 0.55 {
        "up"
    } else if prob_up < 0.45 {
        "down"
    } else {
        "neutral"
    }.to_string();

    let confidence = if prediction == "neutral" {
        (0.5 - (0.5 - prob_up).abs()) * 2.0 * 0.6 + 0.2 // 0.2..0.8
    } else {
        (prob_up - 0.5).abs() * 1.6 + 0.3 // 0.3..1.1 -> cap below
    }.min(0.95);

    let explanation = format!(
        "{}: 24h change {:+.2}%, price {:.4}, volume {} -> momentum {:.2}, vol_score {:.2}.",
        input.asset,
        input.change_24h,
        input.price,
        if vol > 0.0 { format!("{:.2}", vol) } else { "n/a".to_string() },
        momentum,
        vol_score
    );

    let out = Output { prediction, confidence, explanation };
    serde_json::to_string(&out).unwrap()
}
