use wasm_bindgen::prelude::*;
use serde::{Deserialize, Serialize};
use rand::Rng;

#[derive(Deserialize)]
struct Input {
    asset: String,
    price: f64,
    change_24h: f64,
    volume: Option<f64>,
}

#[derive(Serialize)]
struct Output {
    prediction: String,
    confidence: f64,
    explanation: String,
}

fn sigmoid(x: f64) -> f64 {
    1.0 / (1.0 + (-x).exp())
}

#[wasm_bindgen]
pub fn run(input_json: &str) -> String {
    let input: Input = serde_json::from_str(input_json).unwrap_or(Input {
        asset: "ASSET".to_string(),
        price: 100.0,
        change_24h: 0.0,
        volume: Some(0.0),
    });

    let momentum = (input.change_24h / 10.0).clamp(-2.0, 2.0);
    let base = sigmoid(momentum);

    let vol = input.volume.unwrap_or(0.0).max(0.0);
    let vol_score = if vol > 0.0 { (vol.ln() / 10.0).clamp(0.0, 1.0) } else { 0.0 };

    let mut rng = rand::thread_rng();
    let jitter: f64 = rng.gen_range(-0.01..0.01);

    let mut prob_up = (0.75 * base) + (0.2 * vol_score) + (0.05 * (0.5 + jitter));
    prob_up = prob_up.clamp(0.02, 0.98);

    let prediction = if input.change_24h.abs() < 1.0 {
        "neutral".to_string()
    } else if prob_up >= 0.5 {
        "up".to_string()
    } else {
        "down".to_string()
    };

    let confidence = if prediction == "neutral" {
        (0.45 + (input.change_24h.abs() / 100.0)).clamp(0.2, 0.7)
    } else {
        (prob_up - 0.5).abs() * 1.8 + 0.3
    }.min(0.95);

    let explanation = format!(
        "{}: Δ24h {:+.2}%, price {:.4}, volume {} ⇒ prob_up {:.2}.",
        input.asset,
        input.change_24h,
        input.price,
        if vol > 0.0 { format!("{:.2}", vol) } else { "n/a".to_string() },
        prob_up
    );

    serde_json::to_string(&Output { prediction, confidence, explanation }).unwrap()
}
